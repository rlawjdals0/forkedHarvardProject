from flask import Flask, render_template
import gunicorn
import psycopg2

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/snake')
def snake():
    return render_template('snake.html')

@app.route('/pong')
def pong():
    return render_template('pong.html')
