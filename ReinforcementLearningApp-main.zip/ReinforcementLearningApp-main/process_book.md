CSCI S14A - Building Interactive Web Applications for Data Analysis
​
# AI Plays vs. You
​
## Project Plan
​
**Meeting Times**: Sunday at 5pm EST (1-2 hours)
​
**Zoom Link**: https://zoom.us/j/3335128102?pwd=djBqTnpzWG9IV09uNlVVTitqM096dz09
​
**Github Repo**: https://github.com/Harvard-DCE-BIWADA/ReinforcementLearningApp
​
**Website Design Template**:
​
**Website Location**:
 
​
### Team Members
​
Emil Schaumburg - emil.schaumburg@gmail.com

James Kim - 

Nifesimi - 
​
# Milestone 1 Tasks
​
Emil
1. Github repository **COMPLETE**
​

James

1. 
​
All:
1. Choose games to work on and start coding training processes **COMPLETE**
2. Process book and project plan **COMPLETE**
​
# Milestone 2 Tasks
​
Emil
​
1. Train snake algorithm in python **COMPLETE**
2. Improve algorithm by changing parameters **IN PROCESS**
3. Create basic app structure/layout **COMPLETE**
​

James
​

1.
​
​
​
# References & Citations
​
