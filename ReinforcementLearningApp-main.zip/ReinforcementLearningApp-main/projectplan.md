CSCI S14A - Building Interactive Web Applications for Data Analysis
​
# AI Plays vs. You
​
## Project Plan
​
**Meeting Times**: Sunday at 5pm EST (1-2 hours)
​
**Zoom Link**: https://zoom.us/j/3335128102?pwd=djBqTnpzWG9IV09uNlVVTitqM096dz09
​
**Github Repo**: https://github.com/Harvard-DCE-BIWADA/ReinforcementLearningApp
​
**Website Design Template**:
​
**Website Location**:
​
### Team Members
​
Emil Schaumburg - emil.schaumburg@gmail.com
James Kim - 
Nifesimi - 
​
## Project Basics
​
The purpose of this project is to allow the user to play simple games versus an AI trained to play it using reinforcement learning. It will be distributed as a heroku web application. It will be implemented in heroku.
​
The landing page of the website will give options for which game you want to play, and each game will have a separate route that will allow the user to play versus the pre-trained algorithm.
​
## Project Structure
​
/app/				- The folder containing the app.
/app/app.py			- The main app entry point
/app/templates		- Where the templates live.
​
/app/static			- Static files, etc.
​
​
The main components of the app are:
​
1. **Base** - This module contains the skeleton that the entire framework rests on. It is responsible
for checking for compatibility, as well as loading and securing the various sub-modules.
​
2. **Snake** - The snake algorithm was developed using reinforcement learning with the help of the PyTorch module. Using various parameters such as the direction of the food and where danger (such as the border of the map and its own tail) is located relative to the snake, the algorithm suggests a move either left, right, or straight.
​
## Project Timeline
​
Milestone 1: The creation of this document, and development of the project plan and basic structure.

Milestone 2: Fully fleshing out the structure and further developing the algorithms to be fully functional.

Milestone 3: Integrating the algorithms into the app and allowing the user to play.

Milestone 4: Development of end screens, tidying up the menus, and potentially adding more games if time permits.

Milestone 5: Focusing on the design of the app; making it more presentable and user-friendly.

Milestone 6: Present
